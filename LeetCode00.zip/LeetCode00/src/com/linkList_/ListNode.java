package com.linkList_;

public class ListNode {
    public static void main(String[]args){
        public ListNode


    }
}
class Solution {
    //创建一个新方法
    public ListNode removeElements(ListNode head, int val) {
        //一个是链表头节点，一个是待删除元素的编号
        if (head == null) {
            return head;
        }
        //如果没有头节点，就直接返回空就行
        //因为删除可能涉及到头节点，所以设置dummy节点，相当于temp.也是一个虚拟头节点
        //创建新的虚拟头节点，名为dummy,位置时-1
        ListNode dummy = new ListNode(-1, head);
        //dummy指向头节点，在前。头节点在后
        ListNode pre = dummy; //pre节点是dummy
        ListNode cur = head; //当前节点是头节点
        //当前节点不为空的时候
        while (cur != null) {
            if (cur.val == val) { //如果当前节点的值为val
                pre.next = cur.next;
            } else {
                pre = cur;//就是往下遍历
            }
                cur = cur.next;
        }
        return dummy.next;
    }


}